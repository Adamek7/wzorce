package sample;

import javafx.scene.control.Slider;

public class Odlizanie implements Runnable{
    boolean running =true;
    Slider sl;
    double current =10;
    double max=1000;

    Odlizanie(Slider sl, double current, double max, boolean running){
        this.sl=sl;
        this.current=current;
        this.max=max;
        this.running=running;
    }
    Odlizanie(){}

    public  void run(){
        sl.setMin(0);
        sl.setMax(max);
        double time=current;
        double dummy=current;
        while(running) {
            try{
                if(time <  max){
                    time += 100;
                    dummy +=100;
                }else{
                    running = false;
                }
                //System.out.println("dummy "+dummy);

                sl.setValue(dummy);
                Thread.sleep(100);
            }
            catch(Exception e){
                System.out.println(e.getMessage());
                running=false;
            }
        }
    }


}
