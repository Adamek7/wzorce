package sample;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

public class Model implements Model_Interface{
    //wzorzec MVC model nie wie nic o controllerze i view, on tylko przechowuje jakis stan, wykonuje jakaś robotę(algorytmy) cos liczy etc.
    private ArrayList<String> queueMovie = new ArrayList<>();
    private String host ;//wpisane na stale, w celu osobistego tesowania zmienic na odpowiednie wartosci, ew usunac i wpisywac recznie
    private int port; //wpisane na stale, w celu osobistego tesowania zmienic na odpowiednie wartosci, ew usunac i wpisywac recznie
    private double movieLength=0;
    private double currentTime=0;

    @Override
    public ArrayList<String> getQueue() {
        return queueMovie;
    }
    @Override
    public void setQueue(Queue queue) {

        queueMovie.clear();
        queueMovie.addAll(queue);// = queue;
       // System.out.println("Ustanowiono nowa kolejke "+queueMovie.toString());
    }

    @Override
    public String getHost() {
        return host;
    }

    @Override
    public void setHost(String host) {
        this.host=host;
    }

    @Override
    public int getPort() {
        return port;
    }

    @Override
    public void setPort(String port) {
        this.port=Integer.parseInt(port);
    }

    @Override
    public void setMovieLength(double time) {
        movieLength=time;
        //System.out.println("to jest dlugosc filmu "+movieLength);
    }

    @Override
    public double getMovieLength() {
        return movieLength;
    }

    public void setCurrentTime(double time){
        currentTime=time;
    }
    public double getCurrentTime(){
        return currentTime;
    }
}
