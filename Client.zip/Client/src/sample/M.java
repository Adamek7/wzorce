package sample;

import javafx.application.Application;

public class M {
    public static void main(String[] args){
        //startujemy server odbiorczy
        Server serv = new Server();
        serv.setPort(Integer.parseInt(args[0]));

        Thread thread = new Thread(serv);
        thread.start();
        Application.launch(ApplicationView.class, args);
        //System.out.println("aplikacja zakonczyla dzialanie, serwer nadal stoi!!!");
        serv.running=false;
    }
}
