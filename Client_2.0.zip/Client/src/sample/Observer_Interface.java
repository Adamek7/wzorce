package sample;

public interface Observer_Interface {
    void onClick_play();
    void onClick_pause();
    void onClick_scroll(double scrollTime);
    void onClick_addMovie(String link);
    void onClick_host(String host);
    void onClick_port(String port);
    void onClick_register();
    void onClick_unregister();
}
