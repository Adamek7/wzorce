package sample;

import javafx.application.Application;

import javax.swing.*;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Collections;
import java.util.Enumeration;

public class M {
     static String myip;

         public static void main(String[] args) throws SocketException {
             Enumeration<NetworkInterface> nets = null;
             try {
                 nets = NetworkInterface.getNetworkInterfaces();
             } catch (SocketException e) {
                 e.printStackTrace();
             }
             for (NetworkInterface netint : Collections.list(nets)){
                 Enumeration<InetAddress> inetAddresses = netint.getInetAddresses();
                 for (InetAddress inetAddress : Collections.list(inetAddresses)) {
                     String s = inetAddress.toString();
                     s=s.substring(1);
                     if(s.startsWith("192.168",0))
                         myip=s;
                 }
             }



             //startujemy server odbiorczy
             Server serv = new Server();
             serv.setPort(Integer.parseInt(args[0]));
             serv.setIP(myip);

             Thread thread = new Thread(serv);
             thread.start();
             Application.launch(ApplicationView.class, args);
             //System.out.println("aplikacja zakonczyla dzialanie, serwer nadal stoi!!!");
             serv.running=false;

         }


}
