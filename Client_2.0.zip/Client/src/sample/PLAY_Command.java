package sample;

public class PLAY_Command implements Command_Interface {
    private Controller controller;

    PLAY_Command(Controller controller){
        this.controller =controller;
    }

    @Override
    public void execute() {

    }

    @Override
    public void execute(String args) {
        controller.setDisablePlay(true);
        controller.setDisablePause(false);
        controller.model.setCurrentTime(Double.parseDouble(args));
        System.out.println("to jest aktualany czas "+args);
        controller.view.timer.running=false;
        controller.view.startSlider(controller.model.getCurrentTime(),controller.model.getMovieLength());
    }
}
