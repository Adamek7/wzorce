
import java.util.*;

public class C {

    interface Command {
        void execute();
    }

    static class GarbageCollector implements Command {
        public void execute() {
            System.out.println("Garbage out");
        }
    }

    static class WorkingThread implements Command {
        public void execute() {
            System.out.println("WorkingThread executed");
        }
    }

    static class DBCommand implements Command {
        public void execute() {
            System.out.println("DBCommand executed");
        }
    }

    public static List produceRequests() {
        List queue = new ArrayList();
        queue.add(new GarbageCollector());
        queue.add(new DBCommand());
        queue.add(new GarbageCollector());
        return queue;
    }

    public static void workOffRequests(List queue) {
        for (Iterator it = queue.iterator(); it.hasNext(); )
            ((Command) it.next()).execute();
    }

    public static void main(String[] args) {
        List queue = produceRequests();
        workOffRequests(queue);
    }
}