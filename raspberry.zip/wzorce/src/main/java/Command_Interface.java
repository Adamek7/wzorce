public interface Command_Interface {
    void execute();
    void execute(String[] args) throws Exception;
}
