
public interface Forwarder_Interface {

  void handleRequest(String request) throws Exception;
  void registerObserver(Observer o);
  void unregisterObserver(String host,int port);
  void sendMessage(String msg);
  void setCommandMenager(CommandMenager_Interface commMgr);
}
