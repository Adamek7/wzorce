public class REGISTER_Command implements Command_Interface {
    private Forwarder_Interface forwarder;
    private Driver driver;

    REGISTER_Command(Forwarder_Interface controller,Driver driver){
        this.forwarder = controller;
        this.driver=driver;
    }


    @Override
    public void execute() {

    }

    @Override
    public void execute(String[] args) throws Exception {
        forwarder.registerObserver(new Observer(args[0],Integer.parseInt(args[1])));
        if(driver.isPlaying){
            Server.sendGetRequest(args[0],Integer.parseInt(args[1]),"LENGTH|"+ driver.player.getLength());
                Server.sendGetRequest(args[0],Integer.parseInt(args[1]),"PLAY|"+ driver.player.getCurrentTime());
        }else{
            Server.sendGetRequest(args[0],Integer.parseInt(args[1]),"PAUSE");
        }
        String que = driver.movieQueue.toString();
        que = que.replaceAll(" ","");
        String msg = "QUEUE|"+que;
        Server.sendGetRequest(args[0],Integer.parseInt(args[1]),msg);
    }


}
