public class SCROLL_Command implements Command_Interface {
    private Driver_Interface driver;

    SCROLL_Command(Driver_Interface model){
        this.driver =model;
    }

    @Override
    public void execute() {

    }

    @Override
    public void execute(String[] args) throws Exception {
        driver.setScroll((long)Double.parseDouble(args[0]));
    }
}
