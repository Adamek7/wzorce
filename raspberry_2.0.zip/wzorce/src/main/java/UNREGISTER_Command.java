public class UNREGISTER_Command implements Command_Interface {
    private Forwarder_Interface forwarder;

    UNREGISTER_Command(Forwarder_Interface forwarder){
        this.forwarder=forwarder;
    }
    @Override
    public void execute() {

    }

    @Override
    public void execute(String[] args) throws Exception {
        forwarder.unregisterObserver(args[0], Integer.parseInt(args[1]));
    }
}
