public class Observer {
    public String host;
    public int port;
    Observer(String host, int port){
        this.host=host;
        this.port=port;
    }

}
