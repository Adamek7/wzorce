import java.util.Queue;

public interface Driver_Interface {

    void play();
    void pause();
    void addMovie(String movie);
    void finished();
    void setTime(long time);
    void playerIsPlaying();
    void setScroll(long time);


}
