import java.util.LinkedList;
import java.util.Queue;

public class Driver implements Driver_Interface {
     PlayerView player;
    Forwarder_Interface forwarder;
    private long scroll;



    Driver(PlayerView view, Forwarder_Interface forwarder){
        this.player = view;
        this.forwarder = forwarder;
    }

    Queue<String> movieQueue = new LinkedList();
    private String currentMovie ="";
    private long movieLength;
    boolean isPlaying = false;

    public void play(){
        player.updateState_play();
        //long time = player.getCurrentTime();
        //forwarder.sendMessage("PLAY|"+time);
        isPlaying=true;
    }
    public void pause(){
        player.updateState_pause();
        forwarder.sendMessage("PAUSE");
        isPlaying=false;
    }
    public void addMovie(String movie) {
        movieQueue.add(movie);
        String que = movieQueue.toString();
        que = que.replaceAll(" ","");
        String msg = "QUEUE|"+que;
        forwarder.sendMessage(msg);
        if (currentMovie.equals("")) {
            setCurrentMovie();
        }

    }
    public void playerIsPlaying(){
        long time = player.getCurrentTime();
        forwarder.sendMessage("PLAY|"+time);
    }


    private void setCurrentMovie() {
        if(movieQueue.isEmpty()==false){
            currentMovie = movieQueue.poll();
            System.out.println("ustawiam film " + currentMovie);
            player.updateState_currentMovie(currentMovie);
            System.out.println("i to wszystko");

            String que = movieQueue.toString();
            que = que.replaceAll(" ","");
            String msg = "QUEUE|"+que;
            forwarder.sendMessage(msg);
            //long time = player.getCurrentTime();
            //forwarder.sendMessage("PLAY|"+time);
            isPlaying=true;
            System.out.println("i to wszystko");
        }else{
        player.updateState_currentMovie(currentMovie);
        isPlaying=false;
        }

    }


    private int hidden = 2;
    public void finished(){
        hidden--;
        if(hidden ==0){
            System.out.println("finished");
            currentMovie="";
            setCurrentMovie();
            hidden =2;
        }
    }

    @Override
    public void setTime(long time) {
        String msg = "LENGTH|"+time;
        forwarder.sendMessage(msg);
    }

    public void setScroll(long time){
        player.updateState_scroll(time);
    }









}
